package quiz.application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
                                                                                                                    
public class Login extends JFrame implements ActionListener{
 
    JButton rules, back;
   JTextField tfname,regno;
Login() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/login.png"));
        JLabel image = new JLabel(i1);
        image.setBounds(0, -20, 800, 500);
        add(image);
        
        JLabel heading = new JLabel("Brain Trivia");
        heading.setBounds(750, 60, 300, 45);
        heading.setFont(new Font("clarendon-fortune-bold", Font.BOLD, 40));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
        JLabel name = new JLabel("Enter Your Name");
        name.setBounds(735, 150, 300, 20);
        name.setFont(new Font("Mongolian Baiti", Font.BOLD, 18));
        name.setForeground(new Color(30, 144, 254));
        add(name);
        
        tfname = new JTextField();
        tfname.setBounds(735, 190, 300, 25);
        tfname.setFont(new Font("Times New Roman", Font.BOLD, 20));
        add(tfname);
        
        JLabel reg = new JLabel("Enter your Registration no: ");
        reg.setBounds(735, 240, 300, 20);
        reg.setFont(new Font("Mongolian Baiti", Font.BOLD, 18));
        reg.setForeground(new Color(30, 144, 254));
        add(reg);
        
        regno = new JTextField();
        regno.setBounds(735, 280, 300, 25);
        regno.setFont(new Font("Times New Roman", Font.BOLD, 20));
        add(regno);
        
        rules = new JButton("Rules");
        rules.setBounds(735, 350, 120, 25);
        rules.setBackground(new Color(30, 144, 254));
        rules.setForeground(Color.WHITE);
        rules.addActionListener(this);
        add(rules);
        
        back = new JButton("Back");
        back.setBounds(915, 350, 120, 25);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);
        
        setSize(1200, 500);
        setLocation(100, 100);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }    
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == rules) {
            String name = tfname.getText();
            setVisible(false);
            new Rules(name);
        } else if (ae.getSource() == back) {
            setVisible(false);
        }
    }
    
    public static void main(String[] args) {
        new Login();
    }
}
